let table = document.getElementById("table");

function generateC(){

}