let countries = await fetch(`all_countries.json`)
    .then(
        successResponse => {
            if (successResponse.ok) {
                console.log(successResponse)
                return successResponse.json()
            } else {
                console.log(successResponse)
            }
        }
    )


let table = document.getElementById("tbody");

let id = 0;
for (const country of countries.countries) {
    let row = document.createElement("tr");
    row.setAttribute("id", id++)
    row.setAttribute("data-name", country.name_en)
        row.innerHTML = `<td>${country.name_en}</td><td></td><td></td>`;

    table.append(row);
}


let inputEn = document.getElementById("name_en")
let inputEs = document.getElementById("name_es");
let inputGr = document.getElementById("name_gr");


table.addEventListener("click", function (ev) {
    let tds = ev.target.parentElement.children;
    inputEn.value = tds[0].innerText;
    inputEs.value = tds[1].innerText;
    inputGr.value = tds[2].innerText;
})
inputEs.addEventListener("input", function () {

    for (const tr of table.children) {
        if (inputEn.value === tr.getAttribute("data-name")) {
            tr.innerHTML = `<td>${inputEn.value}</td><td>${inputEs.value}</td><td>${inputGr.value}</td>`
            countries.countries[tr.getAttribute("id")].name_es = inputEs.value;
        }
    }
})
inputGr.addEventListener("input", function () {

    for (const tr of table.children) {
        if (inputEn.value === tr.getAttribute("data-name")) {
            tr.innerHTML = `<td>${inputEn.value}</td><td>${inputEs.value}</td><td>${inputGr.value}</td>`
            countries.countries[tr.getAttribute("id")].name_gr = inputGr.value;
        }
    }
});
